# Aula 24 - Autenticação com JWT

Execute cada serviço com:

```bash
uvicorn main:app --reload --port <porta>
```
