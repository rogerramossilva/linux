import jwt
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware

SECRET_KEY = "minha-chave-supersecreta"

def decode_token(token: str):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expirado")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token inválido")

class JWTMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, require_admin=False):
        super().__init__(app)
        self.require_admin = require_admin

    async def dispatch(self, request: Request, call_next):
        auth = request.headers.get("Authorization")
        if not auth or not auth.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Token não enviado")

        token = auth.split(" ")[1]
        payload = decode_token(token)

        if self.require_admin and payload.get("role") != "admin":
            raise HTTPException(status_code=403, detail="Acesso restrito a admins")

        request.state.user = payload
        return await call_next(request)
