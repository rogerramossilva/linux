from fastapi import FastAPI, Request
from shared.jwt_utils import JWTMiddleware

app = FastAPI()
app.add_middleware(JWTMiddleware)

@app.get("/user")
def get_user(request: Request):
    user = request.state.user
    return {"message": f"Olá {user['sub']}, você é um {user['role']}"}
