vault policy write gitlab-pipeline - <<EOF
path "secret/data/devsecops" {
  capabilities = ["read"]
}
EOF

vault token create -policy="gitlab-pipeline" -ttl=1h
