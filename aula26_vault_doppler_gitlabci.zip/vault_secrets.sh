vault kv put secret/devsecops db_user=admin db_pass=Sup3rS3cr3t
vault kv get secret/devsecops
