#!/bin/bash
doppler run --command "echo \$DB_USER && echo \$DB_PASS"
